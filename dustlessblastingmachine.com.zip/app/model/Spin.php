<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Spin extends Model {
    protected $table 		= "spin_wheels";
    public $timestamps = false;
}
