<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Survey extends Model
{
    //
    protected $table 		= "offers";
    
    const CREATED_AT        = 'created_at';
    const UPDATED_AT        = 'updated_at';



}
